/** Automatically generated file. DO NOT MODIFY */
package com.niamhparsley.geonotes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
// From a command prompt, connect your device via USB and enter:
//   adb logcat -s CordovaLog:*
// If it gives you some nonsense about AVD, your phone is not properly connected.

var app = app || {};

// The most recently updated location will always be stored in this variable.
var currentPosition = {};

// This function sets up the watchPosition() method which will constantly
// monitor the device location, updating the currentPosition variable at
// regular intervals. The interval it updates at is definied by the value of
// 'frequency' (in milliseconds between updates).
var startLocationRetrieval = function() {
    var onSuccess = function(position) {
        currentPosition = position;
    };

    // onError Callback receives a PositionError object
    function onError(error) {
        alert('code: ' + error.code + '\n' +
              'message: ' + error.message + '\n');
    }

    // maximumAge:0 means that we never want an old, cached location. We always want
    // the device to fetch a new position for us.
    // The 'timeout' variable is the number of milliseconds we're willing to wait for
    // a location before the system should give up and call onError().
    navigator.geolocation.watchPosition(onSuccess, onError,
      { enableHighAccuracy: true, frequency: 5 * 1000, timeout: 4500, maximumAge: 0 });
};

// Start running the watchLocation() code.
startLocationRetrieval();

// Helper function to convert degrees to radians
function deg2rad(deg) {
    // radians = degrees * pi/180
    return deg * Math.PI/180;
}

app.main = (function() {
    var items = [];
    var itemToAdd = {};

    var attachEvents = function() { // Controllers
        // we keep all the events here
        $('#itemAddBtn')
            .off('click') // it's good to have this
        .on('click', addNewItem);

        $('#helpBtn')
            .off('click') // it's good to have this
        .on('click', help);

        // listening for keypress
        $(document)
            .off('keypress')
            .on('keypress', function(e) {
                // autofocus
                $('#itemInput').focus();
                if (e.which == 13) { // enter
                    addNewItem();
                }
            });
        // listener for fav
        $('.itemFavorite')
            .off('click')
            .on('click', function() {
                var viewToFav = $(this).parent();
                items.forEach(function(v, i) {
                    if (v.view.item[0] === viewToFav[0]) {
                        items[i].model.update(i);
                    }
                });
            });
        // listener for delete
        $('.itemDelete')
            .off('click')
            .on('click', function() {
                var viewToDelete = $(this).parent();
                // compare
                // console.log(items[0].view.item[0]);
                // console.log(viewToDelete[0]);
                // find in items
                items.forEach(function(v, i) {
                    if (v.view.item[0] === viewToDelete[0]) {
                        // console.log(i);
                        // remove it
                        items[i].model.remove(i);
                    }
                });
            });
    };

    // Method to access the last position the device was in 
    // (updated by the watchLocation() code above).
    var getCurrentLocation = function() {
        return currentPosition;
    };

    // Called when the help button is pressed.
    var help = function() {
        // The distance in miles the user can be before the note won't trigger.
        var distanceThreshold = 0.02;

        var alertTriggered = false;
        var currentPosition = getCurrentLocation();

        // Examine each note.
        items.forEach(function(item, i) {
            // Is the note's location close enough to us?
            if (item.model.distanceTo(currentPosition) < distanceThreshold) {
                // Notify the user that a note was saved nearby!
                alert(item.model.item.title);
                alertTriggered = true;  // Remember that we've alerted the user of something.
            }

            // Regardless of distance, log each note that we look at for debugging.
            console.log('Note: "' + item.model.item.title + '", Distance to current position: ' +
                item.model.distanceTo(currentPosition) + ' miles');
        });

        // If we didn't notify the user of any nearby notes, notify them now that
        // we didn't find anything.
        if (!alertTriggered) {
            alert('No notes near your location.');
        }
    };

    var addNewItem = function() {
        console.log('addNewItem called!');
        var title = $('#itemInput').val();
        // add new object
        if (title.length > 2) {
            new Model(title, getCurrentLocation()).add();
            // clear
            $('#itemInput').val('');
            // render
            render();
        } else {
            alert('3 characters up pls.');
        }
    };

    var render = function() {
        console.info('rendering');
        // clear
        $('#itemsContainer').empty();
        items.forEach(function(item, i) { // same things to for()
            // render view
            item.model.render(i);
        });
        attachEvents();
    };

    var Model = function(_title, _currentPosition) {
        this.item = {
            title: _title,
            position: _currentPosition,
            fav: false
        };
        this.add = function() {
            itemToAdd.model = this;
            // chain to view
            new View(this).add();
        };
        this.render = function(i) {
            items[i].view.render();
        };
        this.update = function(i) {
            this.item.fav = !this.item.fav;
            items[i].view.update();
        };
        this.remove = function(i) {
            items[i].view.remove();
            items.splice(i, 1);
        };
        this.distanceTo = function(currentPosition) {
            // Based on the Haversine Formula - computes the distance in miles between
            // two lat/lon positions.
            // JS based on version at http://andrew.hedges.name/experiments/haversine/

            // get values for lat1, lon1, lat2, and lon2
            var t1, n1, t2, n2;
            t1 = currentPosition.coords.latitude;
            n1 = currentPosition.coords.longitude;
            t2 = this.item.position.coords.latitude;
            n2 = this.item.position.coords.longitude;
            
            // convert coordinates to radians
            var lat1, lon1, lat2, lon2;
            lat1 = deg2rad(t1);
            lon1 = deg2rad(n1);
            lat2 = deg2rad(t2);
            lon2 = deg2rad(n2);
            
            // find the differences between the coordinates
            var dlat, dlon;
            dlat = lat2 - lat1;
            dlon = lon2 - lon1;

            // here's the heavy lifting
            var Rm = 3961; // mean radius of the earth (miles) at 39 degrees from the equator
            var a, c, dm;
            a  = Math.pow(Math.sin(dlat/2),2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(dlon/2),2);
            c  = 2 * Math.atan2(Math.sqrt(a),Math.sqrt(1-a)); // great circle distance in radians
            dm = c * Rm; // great circle distance in miles

            return dm;
        };
        return this;
    };

    var View = function(model) {
        this.item = null;

        this.add = function() {
            var locationHtml = 'lat: ' + model.item.position.coords.latitude +
                ',' + ' lon: ' + model.item.position.coords.longitude;
            var locationImgUrl = 'http://maps.googleapis.com/maps/api/staticmap' +
                '?zoom=15&size=320x160&scale=2&markers=color:red%7C' +
                model.item.position.coords.latitude + ',' +
                model.item.position.coords.longitude;
            var card = $('<div></div>').addClass('card').hide(),
                itemFav = $('<span>&#10084;</span>').addClass('itemFavorite').appendTo(card),
                itemTitle = $('<span></span>').addClass('itemTitle').html(model.item.title).appendTo(card),
                itemDelete = $('<span>&times;</span>').addClass('itemDelete').appendTo(card),
                itemMap = $('<img width=100% src="' + locationImgUrl + '">').appendTo(card);
                // itemLocation = $('<p>' + locationHtml + '</p>').addClass('location').appendTo(item);
            this.item = card;
            itemToAdd.view = this;
            // unshift
            items.unshift(itemToAdd);
            // clear
            itemToAdd = {};
        };
        this.update = function() {
            // toggle class
            this.item.children('.itemFavorite').toggleClass('fav');
        };
        this.render = function() {
            // render to itemsContainer
            $('#itemsContainer').append(this.item);
            this.item.fadeIn();
        };
        this.remove = function() {
            this.item.fadeOut();
        };
        return this;
    };

    var init = function() {
        console.info('app init');
        // init existing items in case we have them
        // finally add events
        render();
    };

    return {
        init: init,
        items: items
    };
})();

$(window).on('load', app.main.init);
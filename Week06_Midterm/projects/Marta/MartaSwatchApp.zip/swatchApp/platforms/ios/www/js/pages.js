var app = app || {};

app.pages = (function() {

    // a temp container for a page
    var pageToRender;

    // here is to render pages differently.
    var render = {
        myCollection: function(){
            //blahblah
            console.log('rendering my collection');
            // var dummy = $('<div>hello</div>');
            // $('#view').html(dummy);
            var tpl = $('#tpl-myCollection').html();
            app.pages.pageToRender = _.template(tpl, {

                // dummy: ['NYX','Reds', 'Channel', 'Purple'],
                 transition: 'slideIn'
                
            });
            transition();
            // console.log(app.pages.pageToRender);

           
        },
        myFavorites: function(){

            console.log('rendering myFavorites page');
            // var dummy = $('<div>page</div>');
            // $('#view').html(dummy);
            var tpl = $('#tpl-myFavorites').html();
            app.pages.pageToRender = _.template(tpl, {

                transition: 'slideIn'
                
            });

            transition();

        },
        share: function(){
            console.log('rendering share');
            // var dummy = $('<div>share</div>');
            // $('#view').html(dummy);
            var tpl = $('#tpl-share').html();
            app.pages.pageToRender = _.template(tpl, {

                transition: 'slideIn'
                
            });
            transition();


        },

        addSwatch: function() {
            console.log('rendering addSwatch');
            app.pages.pageToRender = _.template($('#tpl-addSwatch').html(), {
                // dummy: 'blah blah'
                // dummy: ['Apon', 'Dylan', 'Shufei', 'Alec']
                transition: 'slideInFromBottom'
            });
            overlay();
        }
        
    };


    var transition = function() {
        // go advanced -> page transitioning
        // console.log($(app.pages.pageToRender))
        $('#view').append(app.pages.pageToRender);
        setTimeout(function() {
            $('.page').removeClass('slideIn');
            $('.end').addClass('slideOut');
        }, 100);
    };

    var overlay = function() {
        $('body').append(app.pages.pageToRender);
        setTimeout(function() {
            $('.overlayer').removeClass('slideInFromBottom');
        }, 100);
    };

    return {
        render: render,
        pageToRender: pageToRender
    };
})();
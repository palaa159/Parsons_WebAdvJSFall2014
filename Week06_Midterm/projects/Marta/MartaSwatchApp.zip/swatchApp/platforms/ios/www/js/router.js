var app = app || {};

app.router = (function() {
    var route = function() {
    	console.log('routing');
    	var hash = window.location.hash,
    		page = hash.substring(2, hash.length);

    	console.log(page);	

    	if(typeof app.pages.render[page] === 'function'){
    		//we have this hash
    		app.pages.render[page]();
            
    	} else{
    	//sorry we don't
    	// console.log('oops');
    	window.location.hash = '#/myCollection';

    	}

         $('#view').html(app.pages.pageToRender);

    };

    return {
        route: route
    };
})();
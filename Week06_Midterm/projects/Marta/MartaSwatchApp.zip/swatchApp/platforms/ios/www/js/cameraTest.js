  var pictureSource;   // picture source
  var destinationType; // sets the format of returned value

  document.addEventListener("deviceready",onDeviceReady,false);

    // device APIs are available
    function onDeviceReady() {
        pictureSource=navigator.camera.PictureSourceType;
        destinationType=navigator.camera.DestinationType;
    }

    // var pic_count = 0;
    var prevImage = localStorage.getItem('smallImage');
    image.src = "data:image/jpeg;base64," + window.btoa(prevImage);

    function onPhotoDataSuccess(imageData) {
      // console.log(imageData);
      // Get image handle
     // $('#display_pic').append('<img style="display:none;width:50%;height:50%;" id="smallImage_'+pic_count+'" src="" />');
      var smallImage = document.getElementById('smallImage');
      var small_prev_image = document.getElementById('smallPrevImage');
    
      
      small_prev_image.style.display = 'block';
      smallImage.style.display = 'block';

      // Show the captured photo
      // The inline CSS rules are used to resize the image
    
      // var a = window.atob(imageData);
      //       localStorage.setItem('image', a);

      small_prev_image.src = "data:image/jpeg;base64," + imageData;
      smallImage.src = "data:image/jpeg;base64," + imageData;
      //$('#smallImage_'+pic_count).src = "data:image/jpeg;base64," + imageData;

      // pic_count++;
    }

    // Called when a photo is successfully retrieved
    function onPhotoURISuccess(imageURI) {
    //console.log(imageURI);
      // Get image handle
      var largeImage = document.getElementById('largeImage');
      // Unhide image elements
      largeImage.style.display = 'block';
      largeImage.src = imageURI;
    }

    function capturePhoto() {
      // Take picture using device camera and retrieve image as base64-encoded string
      navigator.camera.getPicture(onPhotoDataSuccess, onFail, { quality: 25,
        destinationType: destinationType.DATA_URL });
    }

    function capturePhotoEdit() {
      // Take picture using device camera, allow edit, and retrieve image as base64-encoded string
      navigator.camera.getPicture(onPhotoDataSuccess, onFail, { quality: 20, allowEdit: true,
        destinationType: destinationType.DATA_URL });
    }

    function getPhoto(source) {
      // Retrieve image file location from specified source
      navigator.camera.getPicture(onPhotoURISuccess, onFail, { quality: 25,
        destinationType: destinationType.FILE_URI,
        sourceType: source });
    }

    function onFail(message) {
      alert('Failed because: ' + message);
    }
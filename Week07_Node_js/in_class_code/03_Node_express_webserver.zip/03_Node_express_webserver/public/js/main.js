/* Your code starts here */

var app = app || {};

app.main = (function() {
	var init = function() {
		// app starts running here
	};

	return {
		init: init
	};
})();

app.main.init();
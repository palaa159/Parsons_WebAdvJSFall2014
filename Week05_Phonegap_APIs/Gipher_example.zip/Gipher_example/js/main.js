/* Your code starts here */
/* Giphy API by Giphy
https://github.com/giphy/GiphyAPI
public key: dc6zaTOxFJmzC (limit = 100 responses)

– Search Endpoint
http://api.giphy.com/v1/gifs/search?q=funny+cat&api_key=dc6zaTOxFJmzC
– Get GIF by ID Endpoint (ex. feqkVgjJpYtjy)
http://api.giphy.com/v1/gifs/feqkVgjJpYtjy?api_key=dc6zaTOxFJmzC
– Trending GIFs Endpoint
http://api.giphy.com/v1/gifs/trending?api_key=dc6zaTOxFJmzC
– Random Endpoint
http://api.giphy.com/v1/gifs/random?api_key=dc6zaTOxFJmzC&tag=american+psycho

Options:
– limit=n, n = number

-> How to call an API?
whenever the API is url starts with "http", you can always use jQuery or Zepto ajax call.

$.ajax({
    url: '...',
    dataType: '....', // optional
    method: 'GET', // optional
    success: function(response) {
        // when success
    },
    error: function(err) {
        // when error
    }
});

*/

var app = app || {};

app.main = (function() {
    var giphy = {};

    var init = function() {
        // app starts running here

        // bind user interaction event listener
        attachEvents();
    };

    var attachEvents = function() {
        console.log('attaching events');
        
    };

    return {
        attachEvents: attachEvents,
        giphy: giphy
    };
})();

$(window).on('load', app.main.init);